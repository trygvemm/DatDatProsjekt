class Post:
    def __init__(self, mail, coffeeID, note, score, date):
        self.mail = mail
        self.coffeeID = coffeeID
        self.note = note
        self.score = score
        self.date = date
